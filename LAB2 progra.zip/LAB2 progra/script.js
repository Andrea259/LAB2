document.addEventListener("DOMContentLoaded", function () {
    // Selecciona todas las tarjetas
    const cards = document.querySelectorAll(".card");

    // Asignar eventos
    cards.forEach((card, index) => {
        switch (index) {
            case 0: // Cambia el fondo al pasar el mouse
                card.addEventListener("mouseenter", function () {
                    card.style.backgroundColor = "lightblue";
                });
                card.addEventListener("mouseleave", function () {
                    card.style.backgroundColor = "white";
                });
                break;

            case 1: // Hace vibrar la tarjeta al hacer clic
                card.addEventListener("click", function () {
                    card.style.transform = "rotate(3deg)";
                    setTimeout(() => {
                        card.style.transform = "rotate(-3deg)";
                    }, 100);
                    setTimeout(() => {
                        card.style.transform = "rotate(0deg)";
                    }, 200);
                });
                break;

            case 2: //Muestra un mensaje con efecto de desvanecimiento
                card.addEventListener("click", function () {
                    let mensaje = document.createElement("p");
                    mensaje.innerText = "Pinceladas de Amor es una peli muy hermosa y sentimental";
                    mensaje.style.opacity = "0";
                    mensaje.style.transition = "opacity 1s";
                    card.appendChild(mensaje);
                    setTimeout(() => (mensaje.style.opacity = "1"), 100);
                    setTimeout(() => card.removeChild(mensaje), 3000);
                });
                break;

            case 3: //Abre el enlace de YouTube en una nueva pestaña
                card.addEventListener("click", function () {
                    window.open("https://youtu.be/MOQTg5__abw?si=H5-IbW-G7SDqbfEQ", "_blank");
                });
                break;

            case 4: //Cambia el tamaño de la tarjeta al hacer doble clic
                card.addEventListener("dblclick", function () {
                    card.style.transform = "scale(1.1)";
                    setTimeout(() => {
                        card.style.transform = "scale(1)";
                    }, 500);
                });
                break;

            case 5: //Hace que la tarjeta rebote al hacer clic
                card.addEventListener("click", function () {
                    card.style.transform = "translateY(-10px)";
                    setTimeout(() => {
                        card.style.transform = "translateY(0)";
                    }, 200);
                });
                break;
        }
    });
});
